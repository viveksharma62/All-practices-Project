import data from './Data.json';
import { useNavigate } from 'react-router-dom';
import Cookies from 'universal-cookie';
function Home() {
  //props.purchasedItems
  const x=useNavigate();//return one function
  const handleSubmit=(index)=>
  {
    const product=data[index];//store product object
    const productName=product.title;
    alert(`${productName} has been added to cart`);
    let cookies=new Cookies();
    let existingProductInCart=cookies.get("cart_products");
    if(existingProductInCart === null||existingProductInCart === undefined)
    {
      cookies.set("cart_products",[product]);
    }
    else
    {
      cookies.set("cart_products",[...existingProductInCart,product]);
    }
    if(window.confirm('Want to buy this product? '))
    {
      x('/myCart');
    }
  }
  return (
    <div className="container-fluid">
      <div className='row'>
        {data.map((row,index)=>
        {
          return(
            <div className='col-sm-3 mt-4 text-center' key={index}>
              <img src={row.url} style={{width:"200px"}} alt={'images'} className='card-img m-auto'/>
              <p className='card-title'>{row.title}<br/>{"MRP Rs. "+row.price}</p>
              <input type="button" onClick={()=>handleSubmit(index)} value="Add To Cart" className='btn btn-warning m-3'/>
            </div>
          )
        })}
      </div>
    </div>
  );
}
export default Home;