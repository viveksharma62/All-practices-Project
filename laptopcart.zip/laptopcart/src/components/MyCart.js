import { useEffect, useState } from "react";
import Cookies from "universal-cookie";
function MyCart()
{
  const [price,setPrice]=useState(0);
  const [cartItems,setCartItems]=useState([]);
  const [qtyMap,setQtyMap]=useState(new Map());
  
  const [productMap,setProductMap]=useState(new Map());
  
  useEffect(()=>
  {
    let cookies=new Cookies();
    let existingProductInCart=cookies.get("cart_products");
    setCartItems(existingProductInCart);  
  },[]);
  useEffect(()=>
  {
    var x=new Map();
    var y=new Map();
    for(var i=0;i<cartItems.length;i++)
    {
      var product=cartItems[i];
      var productQty=x.get(product.title);
      if(productQty==null)
      {
        x.set(product.title,1);
      }
      else
      {
        x.set(product.title,productQty+1);
      }
      y.set(product.title,product);
    }
    setQtyMap(x);
    setProductMap(y);
    var sum=0;
    for(var i=0;i<cartItems.length;i++)
    {
      sum+=cartItems[i].price;
    }
    setPrice(sum);
  },[cartItems]);
  const productTlt=(productTitle1)=>
  {
    let newProductArray=[];
    for(var i=0;i<cartItems.length;i++)
    {
      if(productTitle1!=cartItems[i].title)
      {
        newProductArray.push(cartItems[i]);
      }
    }
    setCartItems(newProductArray);
    let cookies=new Cookies();
    cookies.set("cart_products",newProductArray);
  }
  return(
    <div className="container my-4">
      <div className="row">
        <div className="col-7">
          {Array.from(productMap.entries()).map((entry,title)=>
          {
            let [prodTitle,data]=entry;
            return(
              <div className="card">
                <img src={data.url} style={{width:"250px"}} className="m-auto"/>
                <h3 className="card-title">{data.title}</h3>
                <h4>Quantity {qtyMap.get(data.title)}</h4>
                <h5>Price {data.price}*{qtyMap.get(data.title)}={data.price*qtyMap.get(data.title)}</h5>
                <input type="button" onClick={()=>productTlt(data.title)} className="btn btn-warning w-25 m-auto mb-3" value="Delete"/>
              </div>
            );
          })}
        </div>
        <div className="col-5">
          <div className="card">
            <table>
              <tr>
                <th>Product NAme</th>
                <th>Price</th>
              </tr>
              {Array.from(productMap.entries()).map((row,t1)=>
              {
                let [prodTitle1,obj1]=row;
                return(
                  <tr><td>{obj1.title}</td><td>{obj1.price}</td></tr>
                );
              })}
              <tr>
                <td>SubTotal</td>
                <td>{price}</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
export default MyCart;