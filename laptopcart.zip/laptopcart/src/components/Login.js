import { useState } from "react";
function Login() {
        const [isSubmit,setIsSubmit]=useState(false); 
        const [userName,setUserName]=useState(''); 
        const [password,setPassword]=useState(''); 
        const [userNameError,setUserNameError]=useState(''); 
        const [passwordError,setPasswordError]=useState(''); 
        const database=[ 
        { 
        username:'vivek', 
        password:'3084' 
        } 
        ]; 
        const handleSubmit=(e)=> 
        { 
        e.preventDefault(); 
        setUserNameError(''); 
        setPasswordError('');
        const userData=database.find((val)=>val.username===userName); 
 if(userData) 
 { 
 if(userData.password!==password) 
 { 
 setPasswordError('password not valid'); 
 } 
 else 
 { 
 setIsSubmit(true); 
 } 
 } 
 else 
 { 
 setUserNameError('UserName not valid'); 
 } 
 } 
 const renderForm=( 
 <form onSubmit={handleSubmit} style={{marginTop:"15px"}}> 
 <label for="txt"><b>UserName : </b></label> 
 <input type='text' className="mt-5"
id='txt' onChange={(e)=>setUserName(e.target.value)}/> 
 <span>{userNameError}</span> 
 <br/><br/> 
 <label for="txt"><b>password : </b></label> 
 <input type='password' className="mt-3" id='txt' onChange={(e)=>setPassword(e.target.value)}/> 
 <span>{passwordError}</span><br/><br/> 
 <input type='submit' id='btn' className="btn btn-warning m-5"/> 
 </form> 
 ) 
 return( 
  <div className='container m-3'> 
  <div className='App'>
  <h1>Login form</h1> 
 {isSubmit?"Successfully Logged In":renderForm} 
 </div> 
 </div> 
 ) ;
}  
 
  export default Login;